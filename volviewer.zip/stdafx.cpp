
// stdafx.cpp: archivo de c�digo fuente que contiene solo las inclusiones est�ndar
// volviewer.pch ser� el encabezado precompilado
// stdafx.obj contendr� la informaci�n de tipos precompilada

#include "stdafx.h"


